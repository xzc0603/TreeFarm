	/*start*/
	if (WSAStartup(WINSOCK_VERSION, &WSAD))return 1;
    
    /*socket*/
    sd=socket(AF_INET, SOCK_STREAM, 0);
    if (sd == INVALID_SOCKET) {
        WSACleanup(); //finish WS2_32.DLL
        return 2;
    }
    
	/*bind*/
    sock.sin_family = AF_INET; //I will use TCP/IP or UDP protocol
    sock.sin_port = htons(9000);  
    sock.sin_addr.s_addr = inet_addr("192.168.0.172"); //�� 
 	
	if (connect(sd, (struct sockaddr*)&sock, sizeof(sock)))//try to connect server
	{ 
        closesocket(sd);
        WSACleanup();
        return 3;
    }
	

