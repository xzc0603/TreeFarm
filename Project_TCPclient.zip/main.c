#include <stdio.h>
#include <stdlib.h>
#include <WinSock2.h> 
#include <windows.h>
#include <conio.h>
#pragma comment(lib, "wsock32.lib")

#define BUFSIZE 255

SOCKET sd; //socket descriptor
WSADATA WSAD; //winsock data
SOCKADDR_IN sock; //socket struct

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

BOOL WINAPI ConsoleHandler(DWORD dwType) 
{ 
 switch(dwType) { 
 case CTRL_C_EVENT: 
  printf("���� ���α׷��� �����!\n"); 
  closesocket(sd);
  WSACleanup();
  exit(1); 
  break; 
 case CTRL_BREAK_EVENT: 
  printf("break\n"); 
  break; 
 default: 
  printf("Some other event\n"); 
 } 
 return TRUE; 
} 

int main(int argc, char *argv[]) {
	COORD coords={0,0};
	SetConsoleCtrlHandler((PHANDLER_ROUTINE)ConsoleHandler,TRUE);
	WSAEVENT hEventObject;
	int len, b=0,i=0;
	char buf[BUFSIZE + 1]={0,},rcv[BUFSIZE + 1]={0,},cpy[BUFSIZE + 1]={0,};
	#include "init.h"
	send(sd,"connect!",8,0);
	WSAEventSelect(sd, hEventObject, FD_READ|FD_WRITE);
	system("cls");
	while("���⼭���� �ٽ� �ڵ�")
	{	
		if(b!=kbhit())
		{
			buf[i]=getch();
			i++;
		}
		if(buf[i-1]=='\r')
		{
			buf[i]='\n';
			buf[i+1]=0;
			
			send(sd,buf,strlen(buf),0);
			memset(buf, 0, sizeof(buf));
			i=0;
		}
		recv(sd,rcv,BUFSIZE,0);
		if(strlen(rcv))strcpy(cpy,rcv);
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coords);
		printf("%s				\n%s				",cpy,buf);
		memset(rcv, 0, sizeof(rcv));		
	}
	return 0;
}
