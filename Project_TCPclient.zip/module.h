		recv(sd,rcv,BUFSIZE,0);
		if(strlen(rcv))
		{
			printf(rcv);
			memset(rcv, 0, sizeof(rcv));
		}
